/**
 * -------------------------------------
 * @file  mymortgage.c
 * Assignment 1  Header File
 * -------------------------------------
 * @author Mir Sulaiman Sultan, 169042271, sult2271@mylaurier.ca
 *
 * @version 2024-01-20
 *
 * ------------------------------------- */
#include "mymortgage.h"

/**
 *  add your comment
 */
float monthly_payment(float principal_amount, float annual_interest_rate, int years) {
 // your code
}

/**
 *  add your comment
 */
float total_payment(float principal_amount, float annual_interest_rate, int years) {
 // your code
}

/**
 *  add your comment
 */
float total_interest(float principal_amount, float annual_interest_rate, int years) {
 // your code
}