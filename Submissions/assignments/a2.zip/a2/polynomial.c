/**
 * -------------------------------------
 * @file  polynomial.c
 * Assignment 2  Header File
 * -------------------------------------
 * @author Mir Sulaiman Sultan, 169042271, sult2271@mylaurier.ca
 *
 * @version 2024-01-20
 * *
 * ------------------------------------- */

#include <stdio.h>
#include <math.h>
#include "polynomial.h"

#define EPSILON 1e-6

/**
 *  add your comment
 */
float horner(float *p, int n, float x)
{
// your code
}

/**
 *  add your comment
 */
float bisection(float *p, int n, float a, float b)
{
// your code
}