/**
 * -------------------------------------
 * @file  expression.c
 * Assignment #  Header File
 * -------------------------------------
 * @author Mir Sulaiman Sultan, 169042271, sult2271@mylaurier.ca
 *
 * @version 2024-01-20
 *
 * ------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"
#include "stack.h"
#include "expression.h"

QUEUE infix_to_postfix(char *infixstr) {
// your code
}

int evaluate_postfix(QUEUE queue) {
// your code
}

int evaluate_infix(char *infixstr) {
// your code
}